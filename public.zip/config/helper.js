function createAlias(catName){
    catName = catName.toLowerCase();
    catName = catName.replace(" ", "_");
    return catName;
}
module.exports = {createAlias: createAlias };