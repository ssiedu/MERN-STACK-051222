const CategorySchema = require('../model/category.model');
const categoryAlias = require('../config/helper');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

exports.add = async(req, res)=>{
    try{
        var catName = req.body.catName;
        var catAlias = await categoryAlias.createAlias(catName);
        req.body.catAlias = catAlias;
        const newCategorySchema = new CategorySchema(req.body);
        var result = await newCategorySchema.save();
        res.json({"success":"true","msg": "category save successfully"});
    }
    catch(err){
        return res.json({"success":"fail","msg":error});
    }
}

exports.update = async(req, res)=>{
    try{
        var catName = req.body.catName;
        var id = req.body.id;
        var catAlias = await categoryAlias.createAlias(catName);
        req.body.catAlias = catAlias;

        var result = await CategorySchema.findOneAndUpdate({_id: id},{catName: catName, catAlias: catAlias});
        res.json({"success":"true","msg": "category update successfully"});
    }
    catch(err){
        return res.json({"success":"fail","msg":err});
    }
}

exports.delete = async(req, res)=>{
    try{
        var id = req.body.id;    
        var result = await CategorySchema.deleteOne({_id: id});
        res.json({"success":"true","msg": "category delete successfully"});
    }
    catch(err){
        return res.json({"success":"fail","msg":err});
    }
}

exports.get = async(req, res)=>{ 
    try{
        var result = await CategorySchema.find();
        res.json({"success":"true", data: result});
    }
    catch(err){
        return res.json({"success":"fail","msg":error});
    }
}

exports.getId = async(req, res)=>{ 
    try{
        var id = req.query.id;
        var result = await CategorySchema.find({_id: id});
        res.json({"success":"true", data: result});
    }
    catch(err){
        return res.json({"success":"fail","msg":error});
    }
}