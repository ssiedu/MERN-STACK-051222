const ProductSchema = require('../model/product.model');

exports.add = async(req, res)=>{
    try{
        const newProductSchema = new ProductSchema(req.body);
        var result = await newProductSchema.save();
        res.json({"success":"true","msg": "user save successfully"});
    }
    catch(err){
        return res.json({"success":"fail","msg":error});
    }
}

exports.get = async(req, res)=>{ 
    try{
        var result = await ProductSchema.find();
        res.json({"success":"true", data: result});
    }
    catch(err){
        return res.json({"success":"fail","msg":error});
    }
}

exports.getId = async(req, res)=>{ 
    try{
        var id = req.query.id;
        var result = await ProductSchema.find({_id: id});
        res.json({"success":"true", data: result});
    }
    catch(err){
        return res.json({"success":"fail","msg":error});
    }
}