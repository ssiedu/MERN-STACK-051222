const OrderSchema = require('../model/oder.model');

exports.add = async(req, res)=>{
    try{
        const newOrderSchema = new OrderSchema(req.body);
        var result = await newOrderSchema.save();
        res.json({"success":"true","msg": "user save successfully"});
    }
    catch(err){
        return res.json({"success":"fail","msg":error});
    }
}

exports.get = async(req, res)=>{ 
    try{
        var result = await OrderSchema.find();
        res.json({"success":"true", data: result});
    }
    catch(err){
        return res.json({"success":"fail","msg":error});
    }
}

exports.getId = async(req, res)=>{ 
    try{
        var id = req.query.id;
        var result = await OrderSchema.find({_id: id});
        res.json({"success":"true", data: result});
    }
    catch(err){
        return res.json({"success":"fail","msg":error});
    }
}