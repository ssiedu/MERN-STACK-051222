var express = require('express');
var router = express.Router();
var categoryController = require('../controller/category.controller');

/* GET users listing. */
router.route('/addCategory').post(categoryController.add);
router.route('/updateCategory').put(categoryController.update);
router.route('/deleteCategory').delete(categoryController.delete);
router.route('/getCategory').get(categoryController.get);
router.route('/getCategoryId').get(categoryController.getId);

module.exports = router;
