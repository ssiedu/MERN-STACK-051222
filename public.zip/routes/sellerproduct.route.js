var express = require('express');
var router = express.Router();
var sellerProductController = require('../controller/sellerproduct.controller');

/* GET users listing. */
router.route('/addSellerProduct').post(sellerProductController.add);
router.route('/getSellerProduct').get(sellerProductController.get);
router.route('/getSellerProductId').get(sellerProductController.getId);

module.exports = router;
