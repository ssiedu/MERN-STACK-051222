var express = require('express');
var router = express.Router();
var orderController = require('../controller/order.controller');

/* GET users listing. */
router.route('/addOrder').post(orderController.add);
router.route('/getOrder').get(orderController.get);
router.route('/getOrderId').get(orderController.getId);

module.exports = router;
