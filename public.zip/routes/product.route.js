var express = require('express');
var router = express.Router();
var productController = require('../controller/product.controller');

/* GET users listing. */
router.route('/addProduct').post(productController.add);
router.route('/getProduct').get(productController.get);
router.route('/getProductId').get(productController.getId);

module.exports = router;
