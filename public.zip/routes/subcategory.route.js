var express = require('express');
var router = express.Router();
var subCategoryController = require('../controller/subcategory.controller');

/* GET users listing. */
router.route('/addSubCategory').post(subCategoryController.add);
router.route('/getSubCategory').get(subCategoryController.get);
router.route('/getSubCategoryId').get(subCategoryController.getId);

module.exports = router;
