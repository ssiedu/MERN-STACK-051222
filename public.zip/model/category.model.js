const config = require('../config/db');
const mongoose = require('mongoose');

const Schema = mongoose.Schema;

var connection = mongoose.connect(config.database, config.options);

const CategorySchema = new Schema({
    catName: {
        type: String,
        required: true
    },
    catAlias: {
        type: String,
        required: true
    }
},
{ timestamps: {createdAt: "created_at", updatedAt: "updated_at"} }
);

const model = mongoose.model('category', CategorySchema);
module.exports = model;
