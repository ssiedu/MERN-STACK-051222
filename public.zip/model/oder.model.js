const config = require('../config/db');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;
var connection = mongoose.connect(config.database, config.options);

const OrderSchema = new Schema({
    
    uid: {
        type: Schema.ObjectId,
        ref: 'users',
        required: true
    },
    sid: {
        type: Schema.ObjectId,
        ref: 'sellerProduct',
        required: true
    },
    price: {
        type: String,
        required: true
    },
    productName: {
        type: String,
        required: true
    },
    description: {
        type: String
    },
    orderDate: {
        type: Date
    },
    address: {
        type: String
    }
},
{ timestamps: {createdAt: "created_at", updatedAt: "updated_at"} }
);

const model = mongoose.model('order', OrderSchema);
module.exports = model;
