const config = require('../config/db');
const mongoose = require('mongoose');

const Schema = mongoose.Schema;

var connection = mongoose.connect(config.database, config.options);

const UserSchema = new Schema({
    name: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    mobile: {
        type: String,
        required: true
    },
    email: {
        type: String,
    }, 
    gender: {
        type: String,       
    },
    localAddress: {
        type: String
    },   
    deliveryAddress: {
        type: String,
          
    },
    city: {
        type: String,
       
    },
    pincode: {
        type: String,
       
    }
},
{ timestamps: {createdAt: "created_at", updatedAt: "updated_at"} }
);

const model = mongoose.model('users', UserSchema);
module.exports = model;
