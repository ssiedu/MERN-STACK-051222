const config = require('../config/db');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;
var connection = mongoose.connect(config.database, config.options);

const SubCategorySchema = new Schema({
    subCatName: {
        type: String,
        required: true
    },
    subCatAlias: {
        type: String,
        required: true
    },
    cid: {
        type: Schema.ObjectId,
        ref: 'Category',
        required: true
    }
},
{ timestamps: {createdAt: "created_at", updatedAt: "updated_at"} }
);

const model = mongoose.model('subCategory', SubCategorySchema);
module.exports = model;
