const config = require('../config/db');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;
var connection = mongoose.connect(config.database, config.options);

const ProductSchema = new Schema({
    productName: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    scid: {
        type: Schema.ObjectId,
        ref: 'subCategory',
        required: true
    },
    productImage: {
        type: String,
        required: true
    },
    brand: {
        type: String,
    },
    varient: {
        type: Array
    }
},
{ timestamps: {createdAt: "created_at", updatedAt: "updated_at"} }
);

const model = mongoose.model('product', ProductSchema);
module.exports = model;
