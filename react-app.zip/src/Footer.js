function Footer(){
    return(
        <h1>Footer Page</h1>
    )
}


export default Footer;