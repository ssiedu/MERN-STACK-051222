import { useState } from "react";
/**Memo */
function Home(){
    const hello = () => {
        alert("Hello World");
    }
    const city = () =>{
        alert("city");
    }
    const[x, setX] = useState(0);
    const increment = () =>{
        setX((y) => y + 1);
    }
    return(
        <div>
            <h2 style={{color: "blue"}}>{x}</h2>
            <button onClick={increment}>incement</button>
            <h1>Hello World</h1>
            <button onClick={hello}>Click</button>
            <select onChange={city}>
                <option></option>
                <option value="indore">Indore</option>
                <option value="bhopal">Bhopal</option>
                <option value="pune">Pune</option>
                <option value="mumbai">Mumbai</option>
            </select>
        </div>
    )
}


export default Home;