import { useState } from "react";

function Signup(){

    const [userid, setUserid] = useState("");
    const [password, setPassword] = useState("");
    const [email, setEmail] = useState("");
    const [gender, setGender] = useState("");
    const [city, setCity] = useState("");
    const [address, setAddress] = useState("");
    
    const saveUser = () =>{
        const data =  {userid: userid, password: password, email: email, gender: gender, city: city, address: address};
        const response = fetch('http://localhost:4000/users/addUser',{
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(data)
        })
        console.log(response);
    }

    return(
        <div>
            <form>
                <table>
                    <tbody>
                    <tr>
                        <td>User Id</td>
                        <td><input type="text" value={userid} onChange={(e)=> setUserid(e.target.value)} name="userid"/></td>
                    </tr>
                    <tr>
                        <td>Password</td>
                        <td><input type="password" value={password} onChange={(e)=> setPassword(e.target.value)} name="password"/></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td><input type="text" value={email} onChange={(e)=> setEmail(e.target.value)} name="email"/></td>
                    </tr>
                    <tr>
                        <td>Gender</td>
                        <td>
                            Male<input type="radio" onChange={(e)=> setGender(e.target.value)} value="Male" name="gender"/>
                            Female<input type="radio" onChange={(e)=> setGender(e.target.value)} value="FeMale" name="gender"/>
                        </td>
                    </tr>
                    <tr>
                        <td>City</td>
                        <td>
                            <select onChange={(e)=> setCity(e.target.value)}>
                                <option value={city}>select City</option>
                                <option value="indore">Indore</option>
                                <option value="bhopal">Bhopal</option>
                                <option value="pune">Pune</option>
                                <option value="mumbai">Mumbai</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Address</td>
                        <td><textarea onChange={(e)=> setAddress(e.target.value)} value={address} name="address"></textarea></td>
                    </tr>
                   <tr><td><input type="button" value="Submit" onClick={saveUser}></input></td></tr>
                    </tbody>
                </table>
                <p>{userid}</p>
                <p>{password}</p>
                <p>{email}</p>
                <p>{gender}</p>
                <p>{city}</p>
                <p>{address}</p>
            </form>
        </div>

    )
}


export default Signup;