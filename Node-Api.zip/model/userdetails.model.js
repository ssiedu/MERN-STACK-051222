const config = require('../config/db');
const mongoose = require('mongoose');
const user = require('./users.model');

const Schema = mongoose.Schema;

var connection = mongoose.connect(config.database, config.options);

const UserDetailSchema = new Schema({
    user_id: {
        type: mongoose.Types.ObjectId,
        ref: user
    },
    address: {
        type: String,
        required: true
    },
    city: {
        type: String,
        required: true
    },
    phone: {
        type: String,
        required: true
    },
    zip: {
        type: String,
        required: true
    },    
},
{ timestamps: {createdAt: "created_at", updatedAt: "updated_at"} }
);

const model = mongoose.model('usersDetail', UserDetailSchema);
module.exports = model;
