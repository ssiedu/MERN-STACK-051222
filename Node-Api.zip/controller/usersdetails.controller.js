const UserDetialSchema = require('../model/userdetails.model');

exports.add = async(req, res)=>{
    try{
        const newUserDetailSchema = new UserDetialSchema(req.body);
        var result = await newUserDetailSchema.save();
        res.json({"success":"true","msg": "user save successfully"});
    }
    catch(err){
        return res.json({"success":"fail","msg":err});
    }
}

exports.get = async(req, res)=>{ 
    try{
        var result = await UserDetialSchema.find().populate('user_id');
        res.json({"success":"true", data: result});
    }
    catch(err){
        return res.json({"success":"fail","msg":error});
    }
}

exports.getId = async(req, res)=>{ 
    try{
        var id = req.query.id;
        var result = await UserDetialSchema.find({_id: id});
        res.json({"success":"true", data: result});
    }
    catch(err){
        return res.json({"success":"fail","msg":error});
    }
}