var express = require('express');
var router = express.Router();
var userDetailsController = require('../controller/usersdetails.controller');

/* GET users listing. */
router.route('/addUser').post(userDetailsController.add);
router.route('/getUser').get(userDetailsController.get);
router.route('/getUserId').get(userDetailsController.getId);

module.exports = router;
