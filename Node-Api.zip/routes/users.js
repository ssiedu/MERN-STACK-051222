var express = require('express');
var router = express.Router();
var userController = require('../controller/users.controller');

/* GET users listing. */
router.route('/addUser').post(userController.add);
router.route('/getUser').get(userController.get);
router.route('/getUserId').get(userController.getId);

module.exports = router;
