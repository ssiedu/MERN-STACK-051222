module.exports = {
    'database':  'mongodb://localhost:27017/ssi',
    'options': { useNewUrlParser: true, useUnifiedTopology: true }
}

