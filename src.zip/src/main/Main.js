import React from 'react'

function Main() {
    return (
        <div class="welcome">Welcome to our react site</div>

    )
}

export default Main
