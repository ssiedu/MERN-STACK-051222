import React, { useEffect, useState } from 'react'
import Wrapper from './Wrapper'
import { Link } from 'react-router-dom'


function Category() {

    const [category, setCategory] = useState([])

    useEffect(() => {
        fetch('http://localhost:4000/category/getCategory')
            .then(res => res.json())
            .then(data => setCategory(data))
    }, [])

    const del = (_id) => {
        fetch(`http://localhost:4000/category/${_id}`, {
            method: 'DELETE'
        });

        setCategory(category.filter(c => c._id !== _id));

    }
    return (
        <>
            <Link to='/admin/category/create' className='btn'>Add Category</Link>
            <table>
                <thead>
                    <tr>
                        <th>#Id</th>
                        <th>Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        category.map(c => {
                            return (
                                <tr key={c._id}>
                                    <td>{c._id}</td>
                                    <td>{c.catName}</td>
                                    <td>
                                        <Link to={`/admin/categpry/${c._id}/edit`} className='btn'>Edit</Link>
                                        <button onClick={() => del(c._id)}>Delete</button>
                                    </td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
        </>
    )
}

export default Category
