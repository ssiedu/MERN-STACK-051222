var http = require('http');
var express = require('express');

var app = express();

/*Application level middleware */
app.use('/about-us',function(req,res,next){
    console.log("middleware call");
    res.end("site underconstruction");
})
app.get('/',function(req,res){
    res.write("home page");
    res.end();
})

app.get('/about-us',function(req,res){
    res.write("about-us");
    res.end();
})

app.get('/contact-us',function(req,res){
    res.write("contact-us");
    res.end();
})
app.listen(3000);

