var express = require('express');
var user = require('./route/user');
var path = require('path');

var app = express();
/**Build in middleare */
app.use(express.json({limit: '10mb'}));
app.use(express.urlencoded({extended: true, limit: '10mb'}))
app.use(express.static(path.join(__dirname, 'assets')));
console.log("path"+__dirname);
/*Router middleware*/
app.use('/user/',user);

app.listen(3000);

