var express = require('express');
var router = express.Router();

router.get('/',function(req,res){
    res.end("user page");
})

router.get('/contact',function(req,res){
    res.end("contact page");
})
router.get('/about',function(req,res){
    res.end("about page");
})

router.get("/home",function(req,res){
    res.write("<html><body>");
    res.write("<img src='http://localhost:3000/image.webp'>");
    res.write("<form action='register' method='post'>ID<input type='text' name='id'> UserName<input type='text' name='username'><input type='submit'></form>");
    res.write("</body></html>");
    res.end();
})
router.get('/register',function(req,res){
    var id = req.query.id;
    var username = req.query.username
    res.end("Your id is "+id + " and your name is "+ username);
})
router.post('/register',function(req,res){
    var id = req.body.id;
    var username = req.body.username;
    res.end("Your id is "+id + " and your name is "+ username);
})
module.exports = router;
