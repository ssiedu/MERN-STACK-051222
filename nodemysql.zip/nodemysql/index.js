var express = require('express');
var mysql = require('mysql');
var app = express();
const multer  = require('multer');
const upload = multer({ dest: 'uploads/' });
const formidable = require('formidable');
const bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post('/', async function(req,res){
    var connection = mysql.createConnection({
        host     : 'localhost',
        user     : 'root',
        password : 'root',
        database : 'mern'
      });
      connection.connect();
      var form = new formidable.IncomingForm({
        uploadDir: 'f:/',
        keepExtensions: true
      })
      files = [];
      var fields = [];

      await form.parse(req,(err, fields)=>{
        if(err){
            console.log(err);
        }
      }).on('file',(field, file)=>{
        console.log("file event");
        files.push([field, file]);

      }).on('field',(name,field)=>{
        console.log("field event" + name + ""+field);
        fields.push({[name]: field});
      }).on('end',function(){
        console.log("end event");
        console.log(files);
      })

      console.log(files);
      console.log(fields);


     
    //   var sql = "insert into users (username, password, email, dob, amount) values('"+username+"','"+password+"','"+email+"','"+dob+"',"+amount+")";

    //   connection.query(sql, function(err, result, field){
    //         if(err){
    //             console.log(err);
    //         }
    //         else{
    //             console.log(result);
                
    //         }
    //   });
      res.end();
})

app.get('/', function(req,res){
    var connection = mysql.createConnection({
        host     : 'localhost',
        user     : 'root',
        password : 'root',
        database : 'mern'
      });
      connection.connect();
      connection.query("select * from users", function(error, result, field){
            if(error){
                console.log(error);
            }
            else{
                res.write("<html><body>");
               for(i=0; i<result.length; i++){
                    console.log(result[i].id);
                    console.log(result[i].username);
                    console.log(result[i].password);
                    console.log(result[i].email);
                    console.log(result[i].dob);
                    console.log(result[i].amount);

                    res.write(""+result[i].id);
                    res.write(result[i].username);
                    res.write(result[i].password);
                    res.write(result[i].email);
                    res.write(""+result[i].amount);
                    res.write("<br>");
               }
               res.write("</body></html>");
               res.end();
            }
      })
    
})
app.listen(3000);
